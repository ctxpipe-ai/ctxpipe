from pathlib import Path
import os,re,subprocess,json,sys
label,kind=sys.argv[1:];assert re.fullmatch('[a-z0-9-]+',label)
name,directory={'docker':('@tanstack/ai-sandbox-docker@0.3.2','/private/tmp/ctxpipe-native-docker-patch'),'core':('@tanstack/ai-sandbox@0.5.0','/private/tmp/ctxpipe-native-sandbox-patch'),'opencode':('@tanstack/ai-opencode@0.3.4','/private/tmp/ctxpipe-native-opencode-patch')}[kind]
repo=Path('/private/tmp/ctxpipe-recovery-01a07aba');work=Path('/Users/jakubriedl/Documents/Codex/2026-09-07/prior-conversation-with-codex-conversation-role-2/work')
node='/Users/jakubriedl/.volta/tools/image/node/22.16.0/bin/node';pnpm='/Users/jakubriedl/.volta/tools/image/packages/pnpm/lib/node_modules/pnpm/bin/pnpm.cjs';store='/private/tmp/ctxpipe-gate0-pnpm-store'
package=(repo/'package.json').read_text();lock=(repo/'pnpm-lock.yaml').read_text();pattern=r"  '"+re.escape(name)+r"':\n    hash: ([a-f0-9]+)";old=re.search(pattern,lock)[1]
for suffix,body in [('package.json',package),('pnpm-lock.yaml',lock)]:
 with (work/(label+'-before-'+suffix)).open('x') as f:f.write(body)
env=dict(os.environ,npm_config_offline='true',npm_config_ignore_scripts='true',npm_config_store_dir=store);env['PATH']=str(Path(node).parent)+':'+env['PATH']
with (work/(label+'-install.log')).open('x') as f:
 subprocess.run([node,pnpm,'patch-commit',directory],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
 new=re.search(pattern,(repo/'pnpm-lock.yaml').read_text())[1]
 (repo/'package.json').write_text(package);(repo/'pnpm-lock.yaml').write_text(lock.replace(old,new))
 subprocess.run([node,pnpm,'install','--offline','--frozen-lockfile','--ignore-scripts','--store-dir',store],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=300)
print(json.dumps({'old':old,'new':new}))
