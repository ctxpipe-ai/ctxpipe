import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { readFile } from 'node:fs/promises'
import { networkInterfaces } from 'node:os'
import { createServer } from 'node:net'
import { spawn } from 'node:child_process'
import { initLogger } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/node_modules/evlog/dist/index.mjs'
import { withNativeChatFixture } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/test/native-chat-fixture.ts'
import { withNativeHttpsGitFixture } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/test/native-https-git-fixture.ts'
import { streamTanstackWorkspaceChat, warmTanstackWorkspaceChat } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/domain/workspaces/tanstack-workspace-chat.ts'
import { workspaceChatPersistence } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/domain/workspaces/workspace-chat-persistence.ts'
import { withOrgDbContext } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/db/client.ts'
import { workspaces } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/db/schema/workspaces.ts'
import { getLogger } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/observability/logger.ts'
import { eq } from '/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/node_modules/drizzle-orm/index.js'
const require = createRequire('/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/package.json')
const Docker = require('dockerode')
const { parse } = require('dotenv')
initLogger({ enabled:true, silent:true, drain:()=>{}, redact:true })
const live = process.env.CTXPIPE_LIVE_MODEL === '1'
const upstream = live ? parse(await readFile('/Users/jakubriedl/repositories/appear/ctxpipe/apps/backend/.env.local')) : {}
if(live && !upstream.MODEL_PROVIDER_API_KEY) throw new Error('Authorized existing model key unavailable')
const callbackHost = Object.values(networkInterfaces()).flat().find(a=>a?.family==='IPv4' && !a.internal)?.address
assert(callbackHost)
process.env.DOCKER_HOST='tcp://127.0.0.1:63730'
delete process.env.DOCKER_TLS_VERIFY
delete process.env.DOCKER_CERT_PATH
process.env.SANDBOX_CALLBACK_HOST=callbackHost
process.env.SANDBOX_MODEL_PROXY_HOST=callbackHost
const docker=new Docker({timeout:120_000})
const started=Date.now()
let phase='fixture'
const proxyOutput=new Map<string,string>()
const forwards: ReturnType<typeof createServer>[]=[]
const tunnelSockets=new Set<import('node:net').Socket>()
const tunnelChildren=new Set<ReturnType<typeof spawn>>()
async function forwardNestedPort(port:number) {
 const server=createServer(socket=>{
  tunnelSockets.add(socket)
  const env={...process.env}
  delete env.DOCKER_HOST; delete env.DOCKER_TLS_VERIFY; delete env.DOCKER_CERT_PATH
  const child=spawn('docker',['exec','-i','ctxpipe-quota-contract-18173','nc','-w','180','127.0.0.1',String(port)],{env,stdio:['pipe','pipe','pipe']})
  tunnelChildren.add(child)
  socket.pipe(child.stdin!); child.stdout!.pipe(socket)
  child.stderr!.resume()
  child.stdin!.on('error',()=>socket.destroy())
  child.on('error',()=>socket.destroy())
  child.on('close',()=>{tunnelChildren.delete(child);socket.destroy()})
  socket.on('error',()=>socket.destroy())
  socket.on('close',()=>{tunnelSockets.delete(socket);child.stdin!.end()})
 })
 await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)})
 forwards.push(server)
}

try {
 await withNativeHttpsGitFixture({docker,baseImage:'ctxpipe-chat-sandbox:gate4-broker'}, async git=>{
  process.env.SANDBOX_CHAT_IMAGE=git.image
  await withNativeChatFixture(async f=>{
   process.env.SANDBOX_PROVIDER='docker'
   process.env.MODEL_PROVIDER_URL=process.env.MODEL_PROVIDER_URL!.replace('127.0.0.1',callbackHost)
   if(live) {
    process.env.MODEL_PROVIDER_API_KEY=upstream.MODEL_PROVIDER_API_KEY
    process.env.MODEL_PROVIDER=upstream.MODEL_PROVIDER || 'openai-like'
    process.env.MODEL_PROVIDER_URL=upstream.MODEL_PROVIDER_URL || 'https://openrouter.ai/api/v1'
    process.env.MODEL_FAST_NAME=upstream.MODEL_FAST_NAME || 'openai/gpt-5.6-terra?reasoning.effort=low'
   }
   await git.serve(f.directory, async remote=>{
    await withOrgDbContext(f.orgId,db=>db.update(workspaces).set({workspaceRepositoryUrl:remote.url}).where(eq(workspaces.id,f.workspaceId)))
    const input={conversationId:f.conversationId,orgId:f.orgId,orgSlug:f.orgSlug,workspaceId:f.workspaceId,desiredUrl:remote.url,desiredSha:f.sha,defaultBranch:'main',writeStatus:'read_only'}
    phase='prepare';process.stdout.write(JSON.stringify({phase,elapsedMs:Date.now()-started})+'\n')
    const prepared=await warmTanstackWorkspaceChat({...input,prompt:'prepare'})
    if(!prepared.ok) process.stderr.write(JSON.stringify({prepareEvent:getLogger().getContext()})+'\n')
    assert(prepared.ok,prepared.ok ? '' : prepared.error)
    const handle=prepared.handle
    for(const c of await docker.listContainers({filters:{label:['com.tanstack.ai.sandbox.role=proxy']}})) {
     const info=await docker.getContainer(c.Id).inspect()
     const port=Number(info.NetworkSettings.Ports['4096/tcp']?.[0]?.HostPort)
     assert(port>0)
     await forwardNestedPort(port)
     const stream=await docker.getContainer(c.Id).attach({stream:true,stdout:true,stderr:true})
     stream.on('data',chunk=>proxyOutput.set(c.Id,((proxyOutput.get(c.Id)??'')+chunk.toString()).slice(-8000)))
     stream.on('error',error=>proxyOutput.set(c.Id,((proxyOutput.get(c.Id)??'')+'\n'+String(error)).slice(-8000)))
    }
    assert.equal((await handle.process.exec('git config --system credential.helper')).stdout.trim(),'/usr/local/bin/ctxpipe-git-credential')
    assert.equal((await handle.process.exec('gh --version')).exitCode,0)
    assert.equal((await handle.process.exec('printenv MODEL_PROVIDER_API_KEY AUTH_SECRET DATABASE_URL || true')).stdout,'')
    await handle.fs.write('unsaved.txt','preserved during Docker chat')
    const persistence=workspaceChatPersistence()
    const prompts=live ? ['Use the list_repositories MCP tool once, then use bash to run git rev-parse --short HEAD and cat README.md. Do not modify files. Report only the commit and README heading.'] : ['First question','Second question']
    let tools=0
    for(const [index,prompt] of prompts.entries()) {
     phase=`chat-${index+1}`;process.stdout.write(JSON.stringify({phase,elapsedMs:Date.now()-started})+'\n')
     const chunks=[]
     for await(const chunk of streamTanstackWorkspaceChat({...input,prompt,runId:`${f.conversationId}-docker-${index}`,messages:[...(await persistence.stores.messages.loadThread(f.conversationId)),{id:`user-${index}`,role:'user',content:prompt}],abortSignal:AbortSignal.timeout(180_000)})) {
      chunks.push(chunk)
      if(chunk.type==='TOOL_CALL_START') tools++
     }
     assert.deepEqual(chunks.filter(c=>c.type==='RUN_ERROR'),[])
     assert.equal(chunks.filter(c=>c.type==='RUN_FINISHED').length,1)
     const answer=chunks.filter(c=>c.type==='TEXT_MESSAGE_CONTENT').map(c=>c.delta).join('')
     assert(answer.length>0)
     if(live) assert.match(answer,/Native chat workspace/)
     else assert.equal(answer,'Native reply completed.')
    }
    if(live) assert(tools>=2,`Expected MCP and Git tools, got ${tools}`)
    assert.equal(await handle.fs.read('unsaved.txt'),'preserved during Docker chat')
    const transcript=await persistence.stores.messages.loadThread(f.conversationId)
    assert.equal(transcript.filter(m=>m.role==='user').length,prompts.length)
    process.stdout.write(JSON.stringify({result:'pass',runtime:'Bun',live,turns:prompts.length,tools,elapsedMs:Date.now()-started})+'\n')
   }).catch(async error=>{
    for(const c of await docker.listContainers({all:true,filters:{label:['com.tanstack.ai.sandbox.role=proxy']}})) {
     const container=docker.getContainer(c.Id)
     const info=await container.inspect()
     const logs=(proxyOutput.get(c.Id)??'').replaceAll(/[^\x20-\x7e\n]/g,'').slice(-6000)
     process.stderr.write(JSON.stringify({proxy:c.Id,state:info.State,ports:info.NetworkSettings.Ports,logs})+'\n')
    }
    throw error
   })
  },undefined,{listenHost:callbackHost})
 })
} catch(error) {
 process.stderr.write(JSON.stringify({phase,error:String(error),cause:String(error?.cause??''),details:error instanceof AggregateError ? error.errors.map(e=>({message:String(e),stack:e?.stack})) : error?.stack})+'\n')
 process.exitCode=1
}
finally {
 for(const socket of tunnelSockets) socket.destroy()
 for(const child of tunnelChildren) child.stdin?.end()
 await Promise.all(forwards.map(server=>new Promise<void>(resolve=>server.close(()=>resolve()))))
}
