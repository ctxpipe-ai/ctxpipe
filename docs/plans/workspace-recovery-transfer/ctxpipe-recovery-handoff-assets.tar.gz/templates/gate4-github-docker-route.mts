import { createServer, request } from 'node:http'
import { connect, type Socket } from 'node:net'

// External network fixture: route github.com to the controlled HTTPS Git server
// only inside native egress proxies. All Docker operations still reach the daemon.
export async function withGithubDockerRoute<T>(gateway:string, fn:(origin:string, routed:()=>number)=>Promise<T>):Promise<T> {
 if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(gateway)) throw new Error('Invalid fixture gateway')
 const daemonHost=process.env.CTXPIPE_TEST_QUOTA_DOCKER_HOST
 const daemonPort=Number(process.env.CTXPIPE_TEST_QUOTA_DOCKER_PORT)
 if(daemonHost!=='127.0.0.1' || !Number.isInteger(daemonPort) || daemonPort<1 || daemonPort>65535)throw new Error('Set a valid loopback quota endpoint')
 const sockets=new Set<Socket>()
 let routed=0
 const track=(socket:Socket)=>{
  sockets.add(socket)
  socket.on('error',()=>socket.destroy())
  socket.once('close',()=>sockets.delete(socket))
  return socket
 }
 const server=createServer((incoming,outgoing)=>{
  void (async()=>{
   const headers={...incoming.headers,host:`${daemonHost}:${daemonPort}`}
   let body:Buffer|undefined
   if(incoming.method==='POST' && /\/containers\/create(?:\?|$)/.test(incoming.url??'')) {
    const chunks:Buffer[]=[];let size=0
    for await(const chunk of incoming) {
     const bytes=Buffer.from(chunk);size+=bytes.length
     if(size>2*1024*1024) throw new Error('Oversized Docker fixture allocation')
     chunks.push(bytes)
    }
    const allocation=JSON.parse(Buffer.concat(chunks).toString())
    if(allocation.Labels?.['com.tanstack.ai.sandbox.role']==='proxy') {
     allocation.HostConfig.ExtraHosts=[...(allocation.HostConfig.ExtraHosts??[]),`github.com:${gateway}`]
     routed++
    }
    body=Buffer.from(JSON.stringify(allocation))
    headers['content-length']=String(body.length)
    delete headers['transfer-encoding']
   }
   const upstream=request({hostname:daemonHost,port:daemonPort,path:incoming.url,method:incoming.method,headers},response=>{
    outgoing.writeHead(response.statusCode??502,response.headers)
    response.pipe(outgoing)
   })
   upstream.on('error',()=>{if(!outgoing.headersSent)outgoing.writeHead(502);outgoing.end()})
   incoming.once('aborted',()=>upstream.destroy())
   outgoing.once('close',()=>upstream.destroy())
   if(body)upstream.end(body);else incoming.pipe(upstream)
  })().catch(()=>{if(!outgoing.headersSent)outgoing.writeHead(502);outgoing.end()})
 })
 server.on('connection',track)
 server.on('upgrade',(incoming,client,head)=>{
  const upstream=track(connect({host:daemonHost,port:daemonPort}))
  upstream.once('connect',()=>{
   let header=`${incoming.method} ${incoming.url} HTTP/${incoming.httpVersion}\r\n`
   for(let i=0;i<incoming.rawHeaders.length;i+=2)header+=`${incoming.rawHeaders[i]}: ${incoming.rawHeaders[i+1]}\r\n`
   upstream.write(header+'\r\n')
   if(head.length)upstream.write(head)
   client.pipe(upstream);upstream.pipe(client)
  })
  client.once('close',()=>upstream.destroy())
  upstream.once('close',()=>client.destroy())
 })
 await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)})
 const address=server.address()
 if(!address || typeof address==='string')throw new Error('Docker fixture port unavailable')
 try{return await fn(`tcp://127.0.0.1:${address.port}`,()=>routed)}
 finally{
  for(const socket of sockets)socket.destroy()
  await new Promise<void>(resolve=>server.close(()=>resolve()))
 }
}
