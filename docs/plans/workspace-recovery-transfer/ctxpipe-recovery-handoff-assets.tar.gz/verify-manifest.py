#!/usr/bin/env python3
"""Verify the extracted handoff's file inventory and SHA256 values without network access."""
from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,expected in manifest['contents'].items():
    path=root/name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts, name
    assert path.is_file() and not path.is_symlink(), name
    data=path.read_bytes()
    assert len(data)==expected['bytes'], name
    assert hashlib.sha256(data).hexdigest()==expected['sha256'], name
print(f"Verified {len(manifest['contents'])} handoff files; base {manifest['base_sha']}")
