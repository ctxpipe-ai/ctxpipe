"""Run one named baseline check; argv is executed verbatim from the repository root."""
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time

root = pathlib.Path(os.environ['CTXPIPE_REPO']).resolve()
out = pathlib.Path(__file__).resolve().parent / 'private-gate4-evidence' / 'logs'
out.mkdir(parents=True, exist_ok=True)
if len(sys.argv) < 3:
    raise SystemExit('Usage: run-check.py unique-check-name command [args...]')
name, *command = sys.argv[1:]
command = [str(out / pathlib.Path(arg).name) if arg.startswith('docs/plans/workspace-recovery-gate-4/logs/') and arg.endswith('-observed.json') else arg for arg in command]
if not re.fullmatch(r'[a-z0-9][a-z0-9-]*', name) or not command:
    raise SystemExit('Usage: run-check.py unique-check-name command [args...]')
log_path, metadata_path = out / (name + '.log'), out / (name + '.json')
if log_path.exists() or metadata_path.exists():
    raise SystemExit('Choose a new check name; existing evidence is never overwritten.')
env = {key: value for key, value in os.environ.items() if key in (
    'PATH', 'HOME', 'USER', 'TMPDIR', 'SHELL', 'LANG', 'VOLTA_HOME', 'PNPM_HOME',
    'CTXPIPE_REPO', 'CTXPIPE_CALLBACK_HOST', 'CTXPIPE_CHAT_IMAGE', 'CTXPIPE_LIVE_MODEL',
    'CTXPIPE_TEST_QUOTA_DOCKER_HOST', 'CTXPIPE_TEST_QUOTA_DOCKER_PORT', 'CTXPIPE_TEST_QUOTA_RUNNER_ID',
    'MODEL_PROVIDER_API_KEY', 'MODEL_PROVIDER', 'MODEL_PROVIDER_URL', 'MODEL_FAST_NAME')}
fixture_env = {
    'AUTH_SECRET': 'gate0-local-disposable-test-secret-20260907',
    'DATABASE_URL': os.environ['CTXPIPE_TEST_DATABASE_URL'],
    'GRAPH_DB_URI': os.environ['CTXPIPE_TEST_GRAPH_DB_URI'],
    'CI': 'true', 'NO_COLOR': '1', 'TURBO_TELEMETRY_DISABLED': '1',
    'STORYBOOK_DISABLE_TELEMETRY': '1',
}
# Use the explicit app-role URL. Run migrations separately with the owner URL.
env.update(fixture_env)
result_path = env['PATH']
timeout_seconds = 3600 if "kubernetes-memory" in name else 600
start = time.time()
result = {'name': name, 'cwd': str(root), 'command': command,
          'environment': {**fixture_env, 'AUTH_SECRET': '<redacted>', 'DATABASE_URL': re.sub(r'//[^/@]+:[^/@]+@', '//<credentials-redacted>@', fixture_env['DATABASE_URL']), 'PATH': result_path}, 'timeout_seconds': timeout_seconds,
          'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(start)),
          'log': 'logs/' + name + '.log'}
with log_path.open('x') as log:
    log.write(json.dumps(result) + '\n')
    log.flush()
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log,
                               stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
result.update(exit_code=code, duration_seconds=round(time.time() - start, 2))
metadata_path.write_text(json.dumps(result, indent=2) + '\n')
log_text = log_path.read_text()
if env.get('MODEL_PROVIDER_API_KEY'):
    log_text = log_text.replace(env['MODEL_PROVIDER_API_KEY'], '<redacted-model-key>')
log_text = log_text.replace(fixture_env['AUTH_SECRET'], '<redacted>')
log_text = re.sub(r'(postgres(?:ql)?://)[^/@\s\"]+:[^/@\s\"]+@', r'\1<credentials-redacted>@', log_text)
log_path.write_text(log_text)
print(json.dumps({key: result[key] for key in ('name', 'exit_code', 'duration_seconds', 'log')}))
raise SystemExit(code if code >= 0 else 128 - code)
