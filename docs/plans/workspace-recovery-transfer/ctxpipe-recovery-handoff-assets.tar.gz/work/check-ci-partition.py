import json, pathlib, subprocess, os, shutil
root=pathlib.Path(os.environ['CTXPIPE_REPO']).resolve()
node=shutil.which('node'); assert node, 'Node 22 required on PATH'
def listing(lane):
 result=subprocess.run([node,'scripts/ci/test-suite.mjs',lane,'--list'],cwd=root,text=True,capture_output=True)
 if result.returncode: raise RuntimeError(result.stderr)
 return json.loads(result.stdout)
backend,contracts=listing('backend'),listing('contracts')
expected={p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root/'apps/backend',text=True).splitlines() if p.endswith(('.test.ts','.test.tsx','.test.js','.test.mjs','.test.cjs','.test.jsx','.test.mts','.test.cts'))}
assert not set(backend)&set(contracts), 'CI repeats tests between lanes'
assert set(backend)|set(contracts)==expected, 'CI omits or adds test files'
assert len(backend)==len(set(backend)) and len(contracts)==len(set(contracts))
required=json.loads((root/'scripts/ci/contracts.json').read_text())
assert set(contracts)=={p for lane in required.values() for p in lane}
print(json.dumps({'backend_files':len(backend),'contract_files':len(contracts),'total_files':len(expected),'overlap':0,'missing':0}))
