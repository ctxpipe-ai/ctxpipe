# Gate 4 cumulative spec review — current working tree

Review point: committed head `4e31f0f5` plus the uncommitted production-activation tree observed on 2026-09-09, before remediation of the findings below. This is an implementation/spec audit, not Gate 4 acceptance. I did not rerun tests or install dependencies.

## Blockers

### G4-S1 — Files/publish converts infrastructure failures into `missing_sandbox`

**Requirement:** `docs/plans/workspace-chat-recovery.md:673-674` says to delete “catch-and-empty behavior”; the simplification target at `:773` is “Zero infrastructure-error-to-empty conversions.”

`warmTanstackWorkspaceChat` preserves expected conflicts as 409 and converts provider/ensure failures to a distinct 503 (`apps/backend/src/domain/workspaces/tanstack-workspace-chat.ts:373-387`). `warmConversationSandbox` discards that entire result at `apps/backend/src/routes/v1/conversation-files-routes.ts:336-367` (`if (!warmed.ok) return null`). Every Files/publish caller then emits a 409 `missing_sandbox`: tree `:435-436`, blob `:457-458`, status `:471-472`, diff `:505-509`, write `:529-530`, and push `:595-596`.

This makes an unavailable provider, image/policy setup failure, or native ensure fault indistinguishable from an exact `ensureExisting` miss. Preserve the discriminated status/error through `readySandboxHandle` (and its route schemas); reserve null/409 for a proven absence.

### G4-S2 — production base GC compares the agent image ID with the fixed proxy image reference

**Requirement:** Gate 4 proof includes the warm-turn latency budget (`docs/plans/workspace-chat-recovery.md:676-678`), and accepted G4-C specifically preserves “native shared bases/forks” and “base reuse” (`docs/plans/workspace-recovery-gate-4/remaining.md:14`). Production activation requires immutable chat and proxy images (`validation-production-activation.md:8-15`).

Production policy inspects the configured chat image and stores `agentImage.Id` in the native instance row (`apps/backend/src/domain/workspaces/tanstack-workspace-chat.ts:722-739,782-789`; policy returns that ID at `workspace-chat-docker-policy.ts:94-99,138-144`). But `collectUnusedWorkspaceChatBases` compares every Docker row with `WORKSPACE_CHAT_DOCKER_SANDBOX.image` (`workspace-sandbox-cleanup.ts:65-77`), the fixed `node@sha256:...` reference at `chat-runtime.ts:21-28` that production uses as the proxy image (`tanstack-workspace-chat.ts:729,733`). Even if the same image were used, Docker inspect stores `sha256:...`, not the name-at-digest string.

Once the last fork releases a current production base, the collector called by `apps/backend/src/openworkflow/workflows/workspace-tip-check.ts:226-230` therefore marks it obsolete immediately and destroys it. Existing GC coverage supplies the old fixed value as both store and provider image (`sandbox-replica-native.contract.test.ts:390-468`), so it misses the production shape. Compare against the resolved current agent image/policy identity and add that shape to the regression.

### G4-S3 — detached deletion loses egress topology ownership when the agent is already gone

**Requirement:** Gate 4 requires cleanup proof (`docs/plans/workspace-chat-recovery.md:676-678`) and audits delete, idle cleanup, and provider resume (`:680-684`). Accepted G4-D requires delete/idle to use native ownership (`docs/plans/workspace-recovery-gate-4/remaining.md:15`).

Docker destroy learns the ownership key and proxy/network names only from a successful agent inspect: `patches/@tanstack__ai-sandbox-docker@0.3.2.patch:5124-5153`. If the agent is 404, it skips all proxy/network cleanup and only collects fork images (`:5210-5221`). The app’s detached path knows only `providerSandboxId` and intentionally constructs a no-policy provider (`apps/backend/src/domain/workspaces/sandbox-provider.ts:62-75,117-144`); after the no-op destroy and null resume it deletes the authoritative PostgreSQL row (`workspace-sandbox-cleanup.ts:137-161`). An externally removed agent during conversation/workspace deletion therefore strands its proxy and internal network with no durable locator.

This is narrower than the accepted create/recovery behavior: recreating the same deterministic identity can reclaim partial topology. The existing teardown retry proof keeps the agent ownership anchor while proxy/network deletion fails (`sandbox-egress-recovery-native.contract.test.ts:290-395`); it does not cover terminal deletion after agent loss. Persist or otherwise supply the provider ownership locator to detached destroy, and do not delete the row until all matching owned resources are proven absent. Add the missing-agent deletion regression.

## Scope coverage

Reviewed Gate 4 requirements and current ledgers; HTTP, WebSocket, prepare, hydrate/reconstruct, MCP compatibility, Files, publish, conversation/workspace deletion, idle/base collection, and provider resume paths; native instance/lock ownership; revision transitions; OpenCode process/persistence patches; immutable Docker policy, ingress/egress and Compose relay; model/Git run capabilities and broker scope; snapshot/ack recovery; and focused native contract inventory. I found no additional competing registry, process-global correctness store, per-turn GitHub construction, parallel terminal repair, push credential in the Docker agent, or policy-union path.

The active integrated Docker/Bun journey, snapshot fault-injection validation, CI overlap diagnosis/full CI, Railway live conformance, and final evidence closure remain disclosed acceptance work (`remaining.md:31-51`; `validation-production-activation.md:67-88`). They are not counted as findings here.

Result: **3 implementation/proof blockers; no scope-creep finding.**

## Focused closure addendum — 2026-09-09

The original red findings above are retained as the review record. Focused source re-review after remediation reached these conclusions; no broader audit or runtime rerun was performed.

- **G4-S1 closed.** `readySandboxHandle` now returns a discriminated success or failure response and preserves `warmTanstackWorkspaceChat`'s exact status/error. The six Files/push call sites and the pull-request call site return that response instead of manufacturing `missing_sandbox`. The affected route contracts include the provider-unavailable response. Reported focused native validation covered provider unavailability across four Files GETs, save, push and pull request, plus the existing missing/warm-files cases.
- **G4-S2 closed.** The production factory and base collector now share `workspaceChatDockerImage()`. The collector resolves that configured image to its immutable Docker ID once per workspace, outside the SQL callback, and compares only eligible Docker bases with a stored image. The revised native regression first proves that the current immutable base is retained, then proves that a stale-image base is collected.
- **G4-S3 closed.** New egress topology names the proxy from the canonical agent container ID after agent allocation. Live resume/destroy prefers that locator and retains owner-name fallback for legacy live topology. Missing-agent destroy validates managed/schema/key/owner/generation labels, the hardened proxy boundary, matching internal-network identity and absence of foreign endpoints before mutation. Its stop, disconnect, network-remove, proxy-remove order retains the proxy as the retry anchor for every provider-driven failure before completion. Partial-create recovery continues to reject ambiguous proxies and foreign endpoints. The focused native cases cover missing-agent deletion and proxy/network deletion-failure retry. The legacy case where both an old agent and its old-name proxy are externally removed has no recoverable old locator, but legacy egress was not production-activated and provider-owned deletion does not produce that state; it is not a Gate 4 blocker.

Focused conclusion: **G4-S1, G4-S2 and G4-S3 are closed.** The integrated Docker/Bun journey, snapshot validation, CI, Railway live conformance and final acceptance evidence remain pending exactly as disclosed in the Gate 4 ledgers.
