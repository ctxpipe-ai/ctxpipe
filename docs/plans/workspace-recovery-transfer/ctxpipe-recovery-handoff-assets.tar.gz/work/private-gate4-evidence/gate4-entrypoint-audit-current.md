# Gate 4 entry-point and ownership audit

Date: 2026-09-09
Scope: current cumulative working tree; provider selection, Files/publish/delete/idle ownership, and legacy repair/registry paths only.

## Result

No concrete Gate 4 blocker found in the audited production paths.

## Audited ownership flow

- `apps/backend/src/routes/v1/index.ts:70-109` mounts one conversation route tree and the separate OpenAI model proxy. `apps/backend/src/routes/v1/conversations.ts:524-549,605-650` handles reconstruction and HTTP first-turn entry; `apps/backend/src/routes/v1/conversation-websocket.ts:157-220` feeds the same `streamTanstackWorkspaceChat` path for WS. The shared implementation is `apps/backend/src/domain/workspaces/tanstack-workspace-chat.ts:201-249,391-600`.
- Provider selection is centralized in `apps/backend/src/domain/workspaces/sandbox-provider.ts:42-59` and consumed by `tanstack-workspace-chat.ts:656-790`. `sbx` fails closed for the resource-limit contract; Docker builds the immutable image/policy definition; the no-Docker path uses the local-process definition with OS-assigned OpenCode port (`tanstack-workspace-chat.ts:426-428`). No parallel chat registry or manual process owner is selected.
- The shared chat middleware orders persistence/thread ownership before sandbox setup and injects run capabilities after `withSandbox` has supplied the active handle (`tanstack-workspace-chat.ts:443-585`). The provider handle remains the native owner; no app-level process/port allocator is present in this path.
- Files routes acquire `chat-thread:<conversationId>` (`apps/backend/src/routes/v1/conversation-files-routes.ts:400-425`), resolve an existing native handle (`:427-510`), and perform reads/writes through that handle (`:513-557`). Push repeats binding checks, uses the existing handle, and rechecks the captured revision around brokered publication (`:559-624`; `apps/backend/src/domain/workspaces/conversation-publish.ts:98-183`).
- Conversation deletion uses `withDestroyedConversationSandboxes` while the conversation still exists (`apps/backend/src/routes/v1/conversations.ts:565-601`). Cleanup fences workspace, sandbox, and snapshot ownership, destroys the provider resource, then conditionally deletes the persisted row (`apps/backend/src/domain/workspaces/workspace-sandbox-cleanup.ts:96-172`). Provider-id CAS is retained for deletion in `apps/backend/src/domain/workspaces/sandbox-instance-store.ts:314-319` and `apps/backend/src/models/workspace-sandboxes.ts:231-284`.
- Idle cleanup is wired from the `workspace-tip-check` workflow (`apps/backend/src/openworkflow/workflows/workspace-tip-check.ts:209-231`) to `chatSandboxesDueForDestroy`/`destroySandboxesForConversation` and job equivalents. Conversation deletion, workspace relink, and idle GC all reach the same fenced cleanup module; failures persist `destroy_failed` for retry instead of silently deleting ownership state.

## Legacy/registry check

- `LegacyWorkspaceSandboxConflict` in `apps/backend/src/domain/workspaces/sandbox-instance-store.ts:20-31,143-171` is a fail-closed detector for a pre-transition row with no transition key. It does not allocate over or repair the row.
- The `legacy: true` arguments in `apps/backend/src/domain/workspaces/workspace-chat-tools.ts:375-490` are projection/search compatibility flags for legacy published projections. They are not sandbox ownership, process, port, or repair registries; current active projections carry the captured repository SHA.
- No app-level sandbox `Map`, `Set`, memoized handle registry, manual terminal repair path, or duplicate OpenCode entry point was found in the audited production files. Remaining `Map`/`Set` uses are request-local search/projection collections or lock/persistence state.

## Audited paths

- `apps/backend/src/domain/workspaces/sandbox-provider.ts`
- `apps/backend/src/domain/workspaces/chat-runtime.ts`
- `apps/backend/src/domain/workspaces/tanstack-workspace-chat.ts`
- `apps/backend/src/domain/workspaces/sandbox-instance-store.ts`
- `apps/backend/src/domain/workspaces/workspace-sandbox-cleanup.ts`
- `apps/backend/src/domain/workspaces/conversation-files.ts`
- `apps/backend/src/domain/workspaces/conversation-publish.ts`
- `apps/backend/src/domain/workspaces/workspace-chat-callback.ts`
- `apps/backend/src/routes/v1/index.ts`
- `apps/backend/src/routes/v1/conversations.ts`
- `apps/backend/src/routes/v1/conversation-websocket.ts`
- `apps/backend/src/routes/v1/conversation-files-routes.ts`
- `apps/backend/src/routes/v1/workspace-chat-openai.ts`
- `apps/backend/src/openworkflow/workflows/workspace-tip-check.ts`
- `apps/backend/src/models/workspace-sandboxes.ts`
- `apps/backend/src/domain/workspaces/workspace-chat-tools.ts`
