# Native HTTPS Git fixture handoff

Edited path: `/private/tmp/ctxpipe-recovery-01a07aba/apps/backend/src/test/native-https-git-fixture.ts`.

The public `NativeHttpsGitFixture.serve` method now accepts optional `NativeHttpsGitServeOptions`:

- `hostname` (default `host.docker.internal`)
- `repositoryPath` (default `/repo.git`)
- `listenerPort` (default generated high port)
- `basicAuth: { bootstrapToken, readToken }` (default unauthenticated)

`NativeHttpsGitRemote` now exposes `observedRequests()`, which reads a real container-owned JSON request log through Docker exec. Each entry contains only `method`, `path`, and auth category (`none`, `bootstrap`, `read`, or `invalid`).

The real HTTPS server challenges missing/invalid Basic auth with `401` and `WWW-Authenticate`, accepts either configured token, and rewrites the configured public repository path to the physical `/srv/repo.git` Git backend. The generated CA certificate includes `host.docker.internal` and `github.com`; custom DNS hostnames trigger a per-serve certificate reissue. Port 443 runs the fixture server as root so the exact `https://github.com/fixture/workspace.git` URL is usable; defaults retain UID 1000 and the prior URL/port behavior.

Validation run (read-only, no Docker/runtime/install):

- `node_modules/.bin/biome check apps/backend/src/test/native-https-git-fixture.ts` — passed.
- Scoped strict `tsc --noEmit` with Node type roots — passed.

No active exec sessions remain. No package or node_modules mutation was performed. No runtime proof was run per handoff instruction.
