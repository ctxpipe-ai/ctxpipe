# Remote agent — start here

> **Delivery update:** This archive is now temporarily committed on the approved branch at `docs/plans/workspace-recovery-transfer/ctxpipe-recovery-handoff-assets.tar.gz`. No manual upload is required. Follow that directory's README to extract outside the checkout, verify the manifest, then remove the entire tracked transfer directory in a cleanup commit and push. Keep the extracted files for the rest of the task. Earlier references below to manual upload/no handoff commit describe the previous delivery method and are superseded by this update. The implementation base SHA remains unchanged; the transfer commit adds no product code. The WIP fixture is still supplied as a patch inside the archive.

This handoff assumes **no access to the previous agent's computer**. All portable implementation state is either on the Git branch below or in the attached archive. The former computer's directories, databases, containers, model key and package caches do not exist remotely.

## What the user must transfer

Upload **`ctxpipe-recovery-handoff-assets.tar.gz`** to the remote task. It contains this start guide, the comprehensive continuation instructions, the one uncommitted patch, helper templates/configurator, review notes, and selected historical evidence. Uploading the separate Markdown guide is convenient but not required: the archive includes it.

Connect the task to `ctxpipe-ai/ctxpipe`, branch `codex/develop-plan-to-refocus-branch-direction`, with repository read/write and CI access. The pushed checkpoint is `1c7b9657045ed56e62678c5a1d6a6e148925c04a`. All checkpoint pushes to this branch remain approved. No new handoff commit or WIP commit was pushed: **Git alone does not contain the archive's uncommitted fixture extension or private helpers.**

For the live-model journey, provision the already-authorized `MODEL_PROVIDER_API_KEY` in the remote platform's **secret/environment settings**, plus the matching `MODEL_PROVIDER`, `MODEL_PROVIDER_URL`, and `MODEL_FAST_NAME` settings. The key is deliberately absent from Git and the archive. Authorization to use it persists; access does not transfer automatically. Do not paste it in a prompt, public log, or tracked file. Railway access, if supplied, likewise belongs in remote secret settings; it also requires Sandbox entitlement and provider implementation, not merely a token.

The remote executor needs Docker with permission to run the repository's privileged **infrastructure quota runner** (loop-backed Btrfs), enough storage for its 12 GiB filesystem plus image builds, package/image network access, and normal repository CI access. Agent sandboxes remain nonroot and unprivileged. If the hosted agent cannot run that infrastructure, use the existing GitHub CI runner for those validations. Do not substitute ordinary overlay Docker or unsandboxed mode and claim quota/security acceptance. Continue independent implementation, types and reviews while a real infrastructure/secret prerequisite is missing; report the exact unresolved proof.

## 1. Extract, read, and preserve state

Choose paths supplied by the remote platform. Example values below are **placeholders to replace**, not directories on the former Mac:

```bash
export CTXPIPE_REPO='/absolute/path/to/remote/ctxpipe'
export CTXPIPE_HANDOFF='/absolute/path/to/private/extracted-handoff'
mkdir -p "$CTXPIPE_HANDOFF"
tar -xzf /path/to/uploaded/ctxpipe-recovery-handoff-assets.tar.gz -C "$CTXPIPE_HANDOFF"
python3 "$CTXPIPE_HANDOFF/verify-manifest.py"
```

Keep the extracted bundle outside the tracked checkout. Read `CONTINUE-CTXPIPE-RECOVERY.md` in full and the checkout's `AGENTS.md`, `apps/backend/AGENTS.md`, and canonical `docs/plans/workspace-chat-recovery.md`. The comprehensive document supplies architecture, scope, accepted proof, remaining Gates 4–6, and the exact next implementation. This file supplies remote setup.

In a new clone, use the existing branch and full history:

```bash
git clone --branch codex/develop-plan-to-refocus-branch-direction \
  https://github.com/ctxpipe-ai/ctxpipe.git "$CTXPIPE_REPO"
```

If the platform already checked it out, inspect its status, fetch the branch, and select it without discarding existing changes. If shallow, fetch full history. Do not reset to an older checkpoint if the branch has advanced. Verify the checkpoint is an ancestor:

```bash
cd "$CTXPIPE_REPO"
git status --short --branch
git merge-base --is-ancestor 1c7b9657045ed56e62678c5a1d6a6e148925c04a HEAD
```

The single WIP file is `apps/backend/src/test/native-https-git-fixture.ts`. It is **not accepted implementation yet**: only Biome and scoped strict TypeScript ran previously, not Docker runtime/full backend types. On a matching checkout:

```bash
git apply --check "$CTXPIPE_HANDOFF/repository-wip.patch"
git apply "$CTXPIPE_HANDOFF/repository-wip.patch"
```

If forward check fails, check `git apply --reverse --check` to detect an already-applied patch. If neither check passes, inspect the branch's newer file and reconcile deliberately. Never apply twice or drop the changes silently. The archive manifest records base SHA and patch integrity. The original patch was verified to reconstruct the exact WIP from that SHA.

Check CI `34352646163` on the implementation checkpoint once. Its status in the comprehensive document is a historical handoff observation, not a current promise. Do not dispatch a duplicate unchanged run. Diagnose failures from the specific failed step.

## 2. Install the remote runtime once

Use Linux/host-appropriate binaries, not Darwin binaries or former Volta paths:

- Node 22; `pnpm@10.12.1` as pinned in root `package.json`.
- Bun 1.4.2 and OpenCode `opencode-ai@1.18.18`.
- Python 3, Git, Docker CLI/daemon, `psql` client.
- For revision-index proofs: Go 1.25.12, `@ast-grep/cli@0.45.0`, and both Zoekt binaries at commit `596c362fcf1388fe0082acfcfc80c4d172efb7c1`.
- For later UI proof, install Playwright/browser/system prerequisites using the checked-in UI/CI setup; other deployment tools are required when their affected gate runs.

The exact existing installation commands and service definitions are in `.github/workflows/ci.yaml`. For example, after installing the appropriate Node/pnpm:

```bash
cd "$CTXPIPE_REPO"
node --version
pnpm --version
pnpm install --frozen-lockfile
bun --version
opencode --version
```

The first install on a new host is **online**. It applies the tracked native patches from Git. Do not demand the former host's offline store, copy `node_modules`, regenerate the lockfile, or remove patches. Do not install while validations are running. Full backend suites stay in CI; targeted native tests and full project typechecks run at coherent checkpoints.

## 3. Recreate disposable database and graph services

Reuse suitable task-owned services if the platform supplies them. Otherwise reproduce the CI pgvector Postgres 17 and pinned Falkor services, with unique task-owned container names and unused loopback host ports. Example ports 5432/6379 are defaults, not a requirement. Do not remove unrelated services on conflict.

```bash
docker run -d --name ctxpipe-handoff-pg \
  -e POSTGRES_USER=ctxpipe -e POSTGRES_PASSWORD=ctxpipe -e POSTGRES_DB=ctxpipe \
  -p 127.0.0.1:5432:5432 pgvector/pgvector:pg17
docker run -d --name ctxpipe-handoff-graph -p 127.0.0.1:6379:6379 \
  falkordb/falkordb@sha256:52b6583afe7b5ba6bbf5b5f0290bdaa765bd97477b310a590771dc33ebc7b5f5
```

Wait for `pg_isready` and `redis-cli ping`. Use disposable fixture credentials, never a production database. Run all four CI migration/provisioning steps using the owner role:

```bash
cd "$CTXPIPE_REPO/apps/backend"
export DATABASE_URL='postgresql://ctxpipe:ctxpipe@127.0.0.1:5432/ctxpipe'
export DATABASE_APP_PASSWORD='ctxpipe'
pnpm exec drizzle-kit migrate
pnpm exec tsx src/db/migrate-openworkflow.ts
pnpm exec tsx src/db/migrate-checkpoints.ts
pnpm exec tsx src/db/provision-app-role-cli.ts
unset DATABASE_URL DATABASE_APP_PASSWORD
export CTXPIPE_TEST_DATABASE_URL='postgresql://ctxpipe_app:ctxpipe@127.0.0.1:5432/ctxpipe'
export CTXPIPE_TEST_GRAPH_DB_URI='redis://127.0.0.1:6379'
```

Adapt URLs if you chose different ports. Runtime tests must use the `ctxpipe_app` role so RLS executes. Fixtures seed their own test records; no old database dump is needed. Do not run multiple default OpenWorkflow owners concurrently.

## 4. Recreate quota Docker and chat image from Git

Use the **tracked** runner and initializer, which publish only a loopback API, validate Btrfs and build/load the actual chat image. The helper creates a new runner once; retain it for the bounded proof sequence rather than recreating on each test.

```bash
cd "$CTXPIPE_REPO"
docker build -t ctxpipe-sandbox-runner:ci scripts/sandbox-runner
node scripts/ci/start-sandbox-quota-runner.mjs > "$CTXPIPE_HANDOFF/quota-endpoint.json"
```

The JSON returns `CTXPIPE_TEST_QUOTA_DOCKER_HOST`, `CTXPIPE_TEST_QUOTA_DOCKER_PORT`, and `CTXPIPE_TEST_QUOTA_RUNNER_ID`. Export those exact values without evaluating untrusted shell text:

```bash
export CTXPIPE_TEST_QUOTA_DOCKER_HOST="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["CTXPIPE_TEST_QUOTA_DOCKER_HOST"])' "$CTXPIPE_HANDOFF/quota-endpoint.json")"
export CTXPIPE_TEST_QUOTA_DOCKER_PORT="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["CTXPIPE_TEST_QUOTA_DOCKER_PORT"])' "$CTXPIPE_HANDOFF/quota-endpoint.json")"
export CTXPIPE_TEST_QUOTA_RUNNER_ID="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["CTXPIPE_TEST_QUOTA_RUNNER_ID"])' "$CTXPIPE_HANDOFF/quota-endpoint.json")"
export CTXPIPE_CHAT_IMAGE='ctxpipe-chat-sandbox:opencode-1.18.18'
```

Record the new actual image IDs. Former Mac image IDs/container IDs/ports are historical only and may differ on Linux/another architecture. The old broker-tag name does not need recreating: the current tracked Dockerfile contains its helper/gh wrapper. Do not use the old pre-helper image or install tools during a conversation. The full disk-fill test stays in CI.

The portable integrated helper assumes an outer Docker daemon on this executor's normal local Docker socket and a nested API published to its loopback. If your platform's Docker is on another machine, that topology is different: adapt the private fixture's port forwarding and callbacks deliberately or run it on the supported CI host. Do not weaken production admission policy to solve a test network mismatch.

Set `CTXPIPE_CALLBACK_HOST` to an **IPv4 address assigned to the executor**, reachable by the nested proxy, to which the Bun HTTP/model fixtures can bind. Do not assume the first interface or `127.0.0.1` works. Verify reachability from the relevant Docker network with a tiny disposable HTTP listener before running the costly journey. The helper's transparent `docker exec ... nc` forwarding maps inner published OpenCode ports to executor loopback and preserves native authentication. If your topology directly exposes them, adapt that fixture-only forwarding; don't double-bind an occupied port.

```bash
export CTXPIPE_CALLBACK_HOST='REPLACE_WITH_VERIFIED_EXECUTOR_IPV4'
```

No old TLS Compose fixture is needed for the immediate journey. Its previously accepted evidence is on the branch. If touched and needing revalidation, rebuild from the tracked Compose/deployment definitions.

## 5. Configure and use the private helpers

```bash
python3 "$CTXPIPE_HANDOFF/configure.py" --repo "$CTXPIPE_REPO"
```

This only writes two private `.mts` helpers under the extracted bundle's `work/`, substituting the actual checkout path. It refuses to overwrite existing helper edits and checks that the implementation checkpoint is an ancestor. It does not apply the WIP, install packages, fetch credentials, start services, or run tests.

`work/run-gate4-check.py` and `work/check-ci-partition.py` read `CTXPIPE_REPO` and use Node from PATH. The runner reads the explicit app database/graph URLs above, passes only needed model/topology variables to child processes, preserves unique private evidence names, and redacts fixture/model credentials from completed logs. Never intentionally print keys or pass them as command-line arguments.

```bash
python3 "$CTXPIPE_HANDOFF/work/check-ci-partition.py"
python3 "$CTXPIPE_HANDOFF/work/run-gate4-check.py" remote-UNIQUE-types \
  node scripts/ci/typecheck.mjs apps/backend/tsconfig.json \
  scripts/ci/diagnostics/backend.json \
  docs/plans/workspace-recovery-gate-4/logs/remote-UNIQUE-types-observed.json
```

For the deterministic harness after infrastructure/reachability checks:

```bash
python3 "$CTXPIPE_HANDOFF/work/run-gate4-check.py" remote-UNIQUE-docker-bun \
  bun "$CTXPIPE_HANDOFF/work/gate4-integrated-docker-bun.mts"
```

**Validation boundary:** `reference/local-*` contains the exact old helper versions for historical evidence. Portable copies/templates were path/configuration adapted and syntax/configurator checked, but have **not run the Docker journey on the remote host**. The known passing original deterministic journey does not certify the new host. The GitHub-routing helper was never runtime validated, even locally. Do not mistake static checks for runtime acceptance.

Live mode now captures the explicitly supplied `MODEL_PROVIDER*`/`MODEL_FAST_NAME` environment before the test fixture mutates it; it never reads a former checkout's `.env.local`. Set `CTXPIPE_LIVE_MODEL=1` only for the authorized live journey. The current prompt still only proves local Git reading: implement the authenticated Git wiring in section 8 of the comprehensive instructions first. Do not repeatedly run the insufficient live prompt.

`reference/local-repatch-native.py` is historical **reference only** and must not run unchanged. If a native package patch needs changing, create a new editable directory through this host's pnpm patch workflow, retain all current committed patch contents, update matching source/dist/declarations, patch-commit, and inspect exact package/lock changes. Initial install populated the new store; use offline installs only once available. No old temporary patch directory is required. If inspecting Railway SDK, obtain the published `railway@3.11.0` source into private work; its pinned feasibility findings are already bundled. Recheck capabilities as needed using authoritative current sources.

## Transfer inventory and completion target

- **Git:** all committed implementation through the checkpoint; canonical plan, ADRs, Gate 0–3 evidence and Gate 4 ledger, tracked pnpm patches/lockfile, CI, migrations, sandbox Dockerfiles and runtime fixtures.
- **Manual archive:** comprehensive plan continuation, this remote guide, uncommitted fixture patch, private scripts/templates/configurator, review notes, selected result metadata, checksum manifest.
- **Recreate remotely:** dependencies, editable patch directories only if needed, PG/Falkor, Docker runner/images, browser/tooling when needed. No old runtime state is required.
- **Provision securely:** Git/CI credentials as needed; authorized model key and matching settings; entitled Railway access if available. Secrets and live infrastructure are not inside the bundle.
- **Historical only:** old absolute paths in reference scripts and evidence metadata. They explain prior runs and must not be executed as remote paths. Missing bulk `.log` files named in metadata were intentionally not transferred; summarize them from committed reports/this handoff, or reproduce a focused proof when actually needed. Do not claim to have inspected an absent log.

Gates 0–3 are complete. Finish Gate 4's authenticated live integration, honest Railway implementation/conformance and final reviews; then Gate 5 frontend ownership simplification and Gate 6 integrated acceptance/deletion. Preserve the original scope and security constraints. Completing this setup or getting one test green does not close a gate.

Suggested prompt for the remote task:

> Extract the attached archive, read REMOTE-START-HERE.md and CONTINUE-CTXPIPE-RECOVERY.md completely, and continue the existing recovery on codex/develop-plan-to-refocus-branch-direction through Gate 6. You have no access to the former computer; use Git plus the archive, configure your actual checkout paths, preserve the uncommitted fixture patch, and recreate required infrastructure from tracked recipes. Pushes to this branch and use of the supplied model key are already authorized. Keep execution economical and unattended, use bounded independent subagents where useful, and preserve the accepted architecture and proof requirements. Report precise unavoidable infrastructure/credential blockers while completing independent work; do not declare unexecuted conformance passed or stop at another plan.
