# ctxpipe recovery — comprehensive remote continuation handoff

> **Delivery update:** This archive is now temporarily committed on the approved branch at `docs/plans/workspace-recovery-transfer/ctxpipe-recovery-handoff-assets.tar.gz`. No manual upload is required. Follow that directory's README to extract outside the checkout, verify the manifest, then remove the entire tracked transfer directory in a cleanup commit and push. Keep the extracted files for the rest of the task. Earlier references below to manual upload/no handoff commit describe the previous delivery method and are superseded by this update. The implementation base SHA remains unchanged; the transfer commit adds no product code. The WIP fixture is still supplied as a patch inside the archive.

Prepared 2026-09-09, Australia/Melbourne. This is a continuation of an existing implementation, not a request to redesign or restart it. The user wants the accepted recovery plan completed through Gate 6, with economical unattended execution and maintained quality. The user requested this handoff because the current agent is running out of context/tokens. The successor runs remotely with no access to the former computer. Start with the companion `REMOTE-START-HERE.md`: it defines remote paths, transfer, secrets and infrastructure setup. Earlier cloud/network/plan-limit blockers are historical; inspect the actual remote capabilities.

## 1. Start here

**Gates 0–3 are complete. Gate 4 is active. Gates 5–6 are pending and substantial.**

The latest implemented and pushed checkpoint is:

- Repository: `https://github.com/ctxpipe-ai/ctxpipe.git`
- Branch: `codex/develop-plan-to-refocus-branch-direction`
- PR: https://github.com/ctxpipe-ai/ctxpipe/pull/319
- HEAD and last verified pushed SHA: `1c7b9657045ed56e62678c5a1d6a6e148925c04a`
- Subject: `Activate isolated chat brokers and harden native recovery`
- Previous checkpoint: `4e31f0f54a4c37f216690d0c76c1066f55147b36`
- Current CI: https://github.com/ctxpipe-ai/ctxpipe/actions/runs/34352646163
- Last CI observation during handoff: **12 of 13 jobs successful; Tests still running. Backend tests and quota-runner setup passed; deterministic contracts are running, with UI/CLI/CDK tests still pending. No current failure reported.** Re-read this run before drawing conclusions. It tests the pushed SHA, not the WIP fixture below.

**Exactly one repository file is uncommitted at handoff:**

`apps/backend/src/test/native-https-git-fixture.ts`

It adds authenticated GitHub-shaped controlled HTTPS support for the remaining integrated journey. It passed Biome and a scoped strict TypeScript check, but has **not** run against Docker or the full backend typecheck. Preserve/review this WIP; do not treat it as accepted or discard it. A binary git diff is included in the companion asset archive for restoration elsewhere.

The former local processes and subagents were frozen/completed. CI was still active at the last handoff observation. The remote successor inherits no local Docker/Postgres/Falkor state or tool sessions; recreate required disposable services from the tracked recipes in `REMOTE-START-HERE.md`. The old infrastructure is inaccessible and irrelevant to remote setup.

### First actions, in order

1. Read `REMOTE-START-HERE.md`, this handoff, root/backend `AGENTS.md`, and the canonical plan listed below. Read relevant skills when actually working in that area.
2. Fetch the existing branch with full history, confirm HEAD/current CI, and restore the bundled WIP as described in the remote guide. Configure the actual remote checkout path. Do not create a different implementation branch or discard newer remote work.
3. Read the small fixture handoff note and inspect the one WIP diff.
4. Provision remote runtime/services and finish the authenticated Git/live-model integration described in section 8. Use the bundled configurable harness derived from the passing version; validate the new host topology before the costly run.
5. Diagnose only actual new CI failures. Keep raw logs private. Do not launch another identical CI while this run is unchanged/running.
6. Resolve the Railway implementation/access issue honestly, then finish Gate 4's required final independent reviews and pushed acceptance checkpoint.
7. Continue Gate 5, then Gate 6. Do not stop after merely producing a plan or a partial milestone.

## 2. User authority and working expectations

These permissions are already granted in this conversation and travel with this handoff:

- Continue until all gates are completed, without relying on the user watching constantly.
- **All pushes to `codex/develop-plan-to-refocus-branch-direction` are approved. Do not ask again.** Ordinary commits necessary for these checkpoints are within this approved workflow. Do not push to main or force-push during review.
- Use the already-authorized `MODEL_PROVIDER_API_KEY` for the integrated journey, including possible API charges. The remote platform must receive it through secret settings; it is absent from Git/archive. Authorization persists, but remote access to the former checkout does not. Do not repeat the authorization question or expose/commit the key. Missing secret provisioning is a concrete prerequisite, not a reason to stop independent work.
- Local native Docker, Git, PostgreSQL, OpenWorkflow, HTTP/WS, and associated recovery testing are authorized.
- Targeted cheaper subagents are welcome. Use bounded independent tasks. Keep architectural/final adversarial review strong and independent.
- Be economical: reuse valid evidence, avoid repeated broad tests and sprawling fixture/framework work, batch coherent changes and validations.

Do not interpret these as permission to email/Slack people, publish unrelated artifacts, merge the PR, manipulate unrelated accounts, delete other projects' infrastructure, or weaken security constraints. There is no Railway credential/access authorization token available yet; report actual prerequisites and limitations rather than fabricating access.

If your environment requires escalation for network/runtime/git metadata, request tool escalation with a specific reason. Existing user authority is sufficient for the approved operations above. If an automatic approval reviewer still rejects an action, explain the exact action and rejection rather than repeatedly asking for permissions already granted or silently bypassing it.

The previous agent's goal-tool state was stale/blocked from Gate 0; it is not the recovery's current technical state. Repository evidence and this handoff are authoritative. Do not infer a token budget or purchase/reset credits.

## 3. Canonical plan, scope, and architectural constraints

Read these in the recovery repository, not a stale copy under the task's old `work/ctxpipe-recovery` directory:

1. `docs/plans/workspace-chat-recovery.md` — canonical accepted plan and gate protocol.
2. `docs/plans/workspace-recovery-gate-4/remaining.md` — acceptance ledger, with the freshness caveats below.
3. `docs/plans/workspace-recovery-gate-4/validation-production-activation.md` — latest committed implementation/proof summary.
4. `.ai/memory/decisions/ADR-034-native-postgres-sandbox-ownership.md` and ADR-030, ADR-027, ADR-026; use the decisions index for exact names.
5. `docs/plans/workspace-recovery-gate-0/baseline.md` and its scope manifest when performing cumulative/final review.
6. Earlier Gate 2/3 terminal reports only when their invariant is touched. Do not reread thousands of historical log lines.

The authoritative original PR 280 range is:

- Merge base `9072089086f6fad87fbf05572b9f1ff5336e0520`
- PR head `1fad8412525efdeefdfa4899fe9a2f41dfbbc1c8`
- **465 commits, 801 files, +148,441 / −13,326**

The initial shallow range (`296c386..1fad841`, 114 commits/318 files) was wrong. Gate 0 restored full history. Do not use the shallow figures for scope or final deletion metrics. Scope includes the full repository, all 19 Git-backed Workspaces design tickets, accepted PRDs/ADRs, runtime, migrations, deployments, and test/CI paths.

The chosen foundations are mandatory:

- **Native Git** owns repository, immutable revisions, worktrees, branch, diff, commit and push facts.
- **OpenWorkflow** owns durable typed job orchestration, retry and resumption. No second runner lifecycle.
- **Stock TanStack AI** owns chat, persistence, streaming and OpenCode sandbox integration: `chat`, `withPersistence`, `withSandbox`, `opencodeText`, `toWebSocketStream`, `reconstructChat`, native instance/lock stores and `defineSandbox`.
- **Pierre** owns file-tree and diff/editor interaction primitives. Do not rebuild its state in React or add a generic file-browser wrapper.
- ctxpipe owns product policy: tenant authorization, Workspace identity, immutable revision selection, activation, credential scope, and publication rules.

Do not add generic `ChatEngine`, `WorkspaceJobRunner`, `SandboxLeaseStore`, process/handle registries, parallel event journals, mutable per-process definition caches, catch-and-empty repair, or a second lease system. If an upstream package lacks required behavior, prove that native gap and make a narrow tracked package patch with a deletion/upstreaming condition. Do not replace the selected library with a lookalike adapter.

Gate 3 closed at `20cf0791`, with full CI `34295857469` and both cumulative reviews. Preserve its typed transactional writes, protected/default branch rules, captured revision/CAS, idempotent retry, and push-uncertainty recovery. Only the brokered workflow push step holds default-branch push authority; agent sandboxes never receive it.

### Proof rules

- Read `.agents/skills/tdd/SKILL.md` and `mocking.md`; a real collaborator is the oracle. Real PG/RLS, Git, native sandbox and authenticated routes must execute.
- MSW/scripted responses may stand in for **external** model/GitHub boundaries. Do not mock owned stores, routes, hooks, workflow runners, components or native seams and call that proof.
- No new skip/fails/todo, blind retries, hidden diagnostics, widened allowances, or path filters hiding affected modules.
- Node/Bun/esbuild transpilation is not a TypeScript check.
- Backend logging uses evlog; do not add backend `console.*`. Test fixtures should follow the repo's logger instructions.
- Schema changes require Drizzle-generated migrations (`db:generate` and the repo migration skill), not handwritten SQL migration files.
- UI behavior must use real Storybook `play` interactions in the Playwright browser. No new jsdom/happy-dom component proof or mocks of owned components.

## 4. Remote paths, runtime and infrastructure

`REMOTE-START-HERE.md` is the executable setup guide. Use these meanings throughout this document:

| Name | Remote meaning |
| --- | --- |
| `CTXPIPE_REPO` / `recovery_repo` | Absolute path of the remote checkout on the existing branch |
| `CTXPIPE_HANDOFF` / `task_root` / `TASK` | Absolute path where the manual archive is extracted, outside tracked Git |
| `work/…` | Relative to that extracted bundle unless explicitly a repository path |
| `node22` / `bun_cli` | Host-appropriate Node 22 / Bun 1.4.2 found on PATH |

The Git checkpoint contains all committed source, migrations, native patches, plans, CI and sandbox build recipes. The manual archive contains everything uncommitted/private needed for continuation. It contains no dependency tree, database dump, image layer or production credential. Neither the former machine nor its temporary paths are needed.

Recreate pgvector Postgres 17, provision `ctxpipe_app` after the four CI migration steps, and start pinned Falkor. Use explicit `CTXPIPE_TEST_DATABASE_URL` (app role) and `CTXPIPE_TEST_GRAPH_DB_URI` for the portable runner. Fixtures create their own records; the old database is not needed.

Recreate the tracked Docker 27 quota runner with a 12 GiB loop-backed Btrfs filesystem using `scripts/ci/start-sandbox-quota-runner.mjs`. Export its returned host/port/container ID. It builds the current `scripts/chat-sandbox/Dockerfile` as `ctxpipe-chat-sandbox:opencode-1.18.18`, including the credential helper/gh wrapper. Set `CTXPIPE_CHAT_IMAGE` accordingly. Preserve 1 CPU / 1 GiB / 128 PIDs / 4 GiB, UID 1000, exact egress and native cleanup. Privileged infrastructure-runner permission does not permit privileged agent containers.

Old port 63730, container `ctxpipe-quota-contract-18173`, Mac LAN address, Volta/Homebrew paths, and locally built image IDs in historical evidence are **not remote configuration**. Use new inspected endpoints/image IDs and a verified reachable executor IPv4 callback address. The pinned proxy/Node reference remains `node@sha256:8a34c4ab3ea2c5cd194f07e317b2a8f09461d3c8b05c4e34c8ccd56d56024c4d` as specified in Git. Do not use a pre-helper chat image.

Retain the newly created task-owned services across focused runs. Full disk-fill conformance stays in CI. If the executor lacks privileged Btrfs/Docker support, run those proofs on supported CI infrastructure rather than downgrading policy. Existing TLS Compose evidence does not require reconstructing the old Mac fixture unless affected behavior needs revalidation.

Node 22, pnpm 10.12.1, Bun 1.4.2, OpenCode 1.18.18 and native index tools are listed with tracked installation recipes in the remote guide. Initial dependency installation is online; tracked pnpm patches reconstruct the accepted runtime. No original offline store is available. Railway reference source is the published `railway@3.11.0`, obtainable privately if inspection is needed.

## 5. Reliable command workflow and cost controls

Use `work/run-gate4-check.py` from the **task root**. The portable version executes supplied argv from `CTXPIPE_REPO`, reads explicitly configured test database/graph/topology/model environment, uses the current Node 22/Bun PATH, sanitizes metadata, and writes durable uniquely named logs privately. Most commands have a 600-second outer timeout. A nonzero result is a failure, not a skipped proof.

Example (set these shell variables deliberately; don't repurpose HOME/CODEX_HOME):

```bash
task_root="$CTXPIPE_HANDOFF"
recovery_repo="$CTXPIPE_REPO"
node22="$(command -v node)"  # verify v22 first
bun_cli="$(command -v bun)" # verify 1.4.2 first
```

Focused native test:

```bash
python3 "$task_root/work/run-gate4-check.py" UNIQUE-NAME \
  "$node22" apps/backend/node_modules/vitest/vitest.mjs run --root apps/backend \
  src/domain/workspaces/SPECIFIC.contract.test.ts -t 'specific case'
```

Full backend typecheck against the shrinking baseline:

```bash
python3 "$task_root/work/run-gate4-check.py" UNIQUE-TYPES-NAME \
  "$node22" scripts/ci/typecheck.mjs apps/backend/tsconfig.json \
  scripts/ci/diagnostics/backend.json \
  docs/plans/workspace-recovery-gate-4/logs/UNIQUE-TYPES-NAME-observed.json
```

The runner redirects that observed JSON into private logs. UI uses `apps/ui/tsconfig.json` and `scripts/ci/diagnostics/ui.json` similarly.

Current allowances: **backend 124, UI 223, codesearch 0**. They are acknowledged existing debt, not a clean TypeScript project. Do not add allowances. Gate 6 must eliminate them.

Other checks:

```bash
# In recovery checkout:
"$node22" scripts/ci/check-test-policy.mjs
"$node22" node_modules/@biomejs/biome/bin/biome check EXACT_CHANGED_PATHS

docker compose --profile deploy config --quiet
git diff --check -- . ':!patches'

# From task root, or absolute path:
python3 "$task_root/work/check-ci-partition.py"
```

Last partition: **190 backend + 49 required contract files = 239, no overlap/omission**. Proof policy: **436 test/story/config files and 29 command files**. Focused `-t` selections aren't permanent test skips; full CI owns the full contract set.

**Full backend suite runs in CI only.** Don't repeat it locally. Run focused real native checks and full project types locally at coherent milestones. Do not rerun unchanged UI types for backend-only changes. Don't rerun a passing suite unless a new change/failure/concern justifies it.

**No concurrent default OpenWorkflow owners.** Queue/workflow native tests can fight over the default worker state. Serialize those. Independent, explicitly separate Docker resource fixtures may coexist, but avoid simultaneous heavy nested image commits/quota checks. Never install dependencies while runtime checks or typechecks are active.

Use direct Node 22 commands, not a `pnpm exec` path that silently selects Node 24 via a different Volta/pnpm wrapper. Tests once hung because the fault proxy lacked Docker HTTP upgrade forwarding; do not misattribute that resolved defect to Node 24, but avoid introducing version ambiguity.

Don't poll unchanged CI or dump whole logs. Read concise summaries, then the specific failed test/error. Watch CI while doing independent useful work. Keep new raw logs and machine metadata under private task `work/`, never in the repository.

### CI dispatch and push

Current CI was explicitly dispatched because this actor's push-only run was skipped by the workflow's push/PR XOR rules. It is `34352646163`; don't dispatch a duplicate just because the push run `34352578486` says skipped.

```bash
# In recovery checkout:
gh run view 34352646163 --json status,conclusion,jobs,url
gh run view RUN_ID --log-failed > "$task_root/work/private-gate4-evidence/logs/UNIQUE-ci-failed.log"

git push origin HEAD:codex/develop-plan-to-refocus-branch-direction
# Only when a new coherent pushed candidate needs a full CI run:
gh workflow run ci.yaml --ref codex/develop-plan-to-refocus-branch-direction
```

Checkpoint pushes are already approved. Verify the remote SHA before declaring a gate accepted. Don't force-push active review history or push unrelated branches.

## 6. Native package patches — preserve these carefully

Runtime behavior is partly implemented in tracked pnpm patches. Editing only app source or only TypeScript in a temporary package directory will not change the installed runtime. Source, matching distribution files, tracked patch and lock hash must stay synchronized.

Current installed/checkpoint hashes:

| Package | Hash |
| --- | --- |
| `@tanstack/ai-sandbox@0.5.0` | `2467bd693253a2d003138e8b40786d9a2971e18e4458a1cbda421b95dc9f0aa6` |
| `@tanstack/ai-sandbox-docker@0.3.2` | `bd889b97c6cf7779f5426dd44ca92aac5ca3abe7fde8d71478da28251b02fffb` |
| `@tanstack/ai-opencode@0.3.4` | `f20a14fd17dca1c468a34a7a3d92fc74337f76506d83fdc7c7a553cb0c8cf893` |
| `@tanstack/ai-sandbox-local-process@0.2.4` | `64d1ad35f9d05adda70ef23dde757c1458fd7c13bc4cdfdbc18b2e98c0588563` |
| `@tanstack/ai-persistence@0.5.1` | `a7d90715232a11c03cd3ca8d6d83992dcbd06f8c02b079a15115f876af043eb5` |
| `@opencode-ai/sdk@1.18.18` | `34ccf0edd5a554bda9e0892871094e3b8cda3dcc368ab4cd04fe6a5d91619ea8` |

No temporary editable package directories transfer to the remote agent. The authoritative patches and lock hashes are in Git and applied by the first frozen install. If a patch changes, establish new pnpm editable state on the remote host while preserving **all existing committed corrections**. Do not start from pristine upstream and lose accepted changes. Verify matching source, distribution and declarations; inspect the patch, package configuration and lock hash after patch-commit.

`reference/local-repatch-native.py` is a historical reference for the previous sequential patch/install workflow, **not a remote executable**. It contains old paths and assumes a populated offline store. Read its intent if useful, but use this host's pnpm paths/store/edit metadata. Preserve the lockfile except justified target changes; don't accept unrelated peer churn. Run installs only after runtime/typecheck processes have stopped. Back up candidate package/lock changes privately with unique names before mutation.

Important native corrections to preserve:

- Core persists an initialized instance before snapshot IO; resume completes a missing initial snapshot on the same live instance.
- Failed bootstrap/persistence cleanup errors remain visible. No catch-and-empty fallback.
- Docker snapshot acknowledgement recovery only accepts a **newly published** image tag compared with pre-call inspection. It does not claim to solve every possible delayed commit/retag/dangling-image case.
- Native egress proxy owns isolated networking, exact host/path admission, authenticated published ingress and renewable tool grants. Agent/proxy logging is `LogConfig: none`; don't change that merely to get test logs. Use bounded live attach if needed.
- Accepted socket errors destroy the affected socket, not the entire proxy.
- HTTP timeout bounds connection establishment; it must not kill legitimate prompts waiting more than five seconds for response headers. Caller disconnect and grant revocation still abort IO.
- After allocation, proxy name derives from the canonical agent container ID, preserving a detached cleanup anchor after external agent removal. Cleanup validates full ownership/generation/boundary/network endpoints, then stop → disconnect → remove network → remove proxy last. Existing live legacy names and partially created topology remain supported. Don't erase the retry anchor before risky cleanup.
- Native OpenCode drains bounded diagnostics after readiness, observes process exit once, sanitizes errors, handles SSE readiness/terminal ordering, and keeps proper SDK typing. Diagnostics resolved a misleading local published-port failure; do not reintroduce fixed global OpenCode ports or a process registry.

## 7. What Gate 4 has actually achieved

The committed ledger has historical detail. These are the important accepted facts and remaining limits.

### Ownership/chat/revision foundation

- Native PostgreSQL instance/lock stores with tenant/owner/revision fences, short SQL transactions, lock renewal/revocation, restart/replica reuse, allocation/deletion races, collision protection, and legitimate provider replacement.
- Shared stock TanStack HTTP/WS/prepare paths, two turns, offsets, transcript/terminal agreement, reconstruction, cancellation and simultaneous-send preservation.
- Native bases/forks, warm reuse, dirty-file preservation, revision conflicts/repair, provider loss and collection.
- Files/publication/deletion/idle use native handles; prior custom registries/manual terminal repair removed.
- Current factory builds immutable per-workspace policy/definition; no tenant host accumulation in a global definition.

### Activated Docker deployment and credentials

- Fixed 1 CPU / 1 GiB / 128 PIDs / 4 GiB writable disk, UID/GID 1000, no privileged/device fallback.
- Prebuilt immutable chat/proxy images; request handling inspects, never installs/builds/pulls tools during a conversation.
- Agent isolated network and disabled direct DNS; trusted proxy has controlled networking. Exact Git/model/MCP routes, metadata/direct-route denial, authenticated ingress, renewable/revocable admission.
- Credential-free model relay in the nested daemon's network namespace binds only its default bridge gateway; resolves backend DNS per connection and survives backend IP replacement. It has no Docker credentials/socket/cert mounts.
- Separate signed model and Git run capabilities tied to the **actual native transcript-lock owner**, not whichever owner happens to be present later.
- Broker validates purpose, live owner, tenant, current conversation/workspace revision, and exact linked repository/connection scope. It revalidates after external issuance.
- Installation tokens have only contents/issues/pull-requests/metadata read permissions; maximum 500 repositories; issuer expiry checked independently of Octokit cache with refresh inside the last minute.
- Docker create secrets omit the old timed model token. Native env injection supplies run capabilities before OpenCode starts. Model-provider and App private keys stay outside the sandbox.
- Fixed in-image Git helper obtains short-lived tokens. gh wrapper passes its token only to its child. No token file cache.
- Job cleanup uses the job store and exact captured provider-ID deletion CAS; native chat-only storage is not used to delete job rows. Upsert replacement remains allowed.
- Files/PR/push return the native preparation error/status instead of translating unavailable infrastructure into `missing_sandbox`.
- Base GC compares the configured **agent immutable image ID**, not the fixed Node/proxy reference; image discovery occurs outside SQL connection ownership.

### Passing evidence worth reusing

Selected historical result JSON files are bundled under `work/private-gate4-evidence/logs`; bulk raw logs are intentionally omitted. These are previous-host results, not proof executed on the new host. Committed gate reports contain broader evidence summaries. Do not assume a `.log` named inside metadata is attached.

| Check | Result |
| --- | --- |
| `integrated-docker-bun-response-deadline` | **Pass**, 189.33s including cleanup. Real Bun + quota Docker + HTTPS Git + production factory/model broker + stock OpenCode, two turns, dirty-file preservation and transcript assertions. External model is deterministic HTTP. `tools: 0`, so **not** live-model/tool/authenticated-helper acceptance. |
| `https-git-quota-prepare-300s` | Pass; test 177.3s / ~189.31s total. HTTPS clone, actual resource/user constraints, dirty reuse, revision advance, provider loss/recovery. |
| `native-snapshot-recovery-2205` | 2/2 pass, 52.1s. Rejected commit retains durable base for same-container retry; lost successful-commit response recovers with one commit. |
| `native-egress-detached-and-retry-green-2248` | 3/3 pass, 80.39s. Missing-agent detached cleanup, proxy-delete retry, network-delete retry; another owner untouched. |
| `egress-response-delay-green` | Pass, 12.7s. Outbound HTTP and authenticated ingress both tolerate real 5.5s delay before headers; CONNECT-reset survival also passes. |
| `files-provider-errors-green` | 4 selected cases pass, 16.32s. Provider unavailable across Files/save/push/PR, plus warm-files success and actual missing sandbox. |
| `files-provider-errors-typed-json` | Final 2 unavailable-provider cases pass, 12.5s, after fixing typed OpenAPI responses. |
| `current-base-image-green` | 2 pass, 74.05s. Retain current immutable image base; collect obsolete base after last fork release. |
| `review-corrections-typed-response` | Complete backend types pass, 96.23s, 124 acknowledged diagnostics, no additions. |
| `production-broker-ui-types` | Prior complete UI check pass, 223 acknowledged diagnostics; no UI changes since. |
| `production-broker-owner-scope-green` | Pass, 24.32s. Exact scope, refresh, unlink-during-mint, 501 boundary, release; separate native OpenCode/model-capability turns. |
| Native capability/lock cases | 3 pass: actual acquisition owner, replacement/revocation/expiry and related ownership checks. |
| Scoped formatting/policy/partition/Compose | Passed at checkpoint: 32 changed formatted files, 436 policy files/29 commands, 190+49 partition, valid deploy config. |

Also reuse the earlier native resource, remote Docker TLS, relay replacement, policy denial, teardown, process/port, ownership/collision, RLS, workspace Files/job and provider-replacement proofs unless new changes affect them.

### Prior CI failure versus current run

CI `34342455444` on `4e31f0f5` passed 12 jobs and **315/318 contracts**, but failed:

1. Disk quota probe was killed by memory pressure before reaching quota. It now uses `dd ... oflag=direct conv=fsync` to bypass page cache. A tiny real direct-write check passed; full fill must be confirmed in CI.
2. Overlapping chat saw an OpenCode connection reset during session creation. Better bounded native process diagnostics are now installed. Do **not** claim this cause is solved until current CI proves it or exposes it. Port 4096 in the old log belonged to a later cancellation test; it was not evidence of a port collision.
3. Job-row cleanup incorrectly entered the chat-only store. Corrected and native targeted regressions pass.

UI/CLI/CDK test steps downstream of that old contract failure did not execute then. Current CI, not old partial success, must establish their final state.

The current native proxy delay fix is a separate confirmed defect; it is not proof that it caused the older unsandboxed overlapping-chat reset.

## 8. Exact next implementation: authenticated Git + live model/tools journey

### What already exists

Private working harness:

`TASK/work/gate4-integrated-docker-bun.mts`

The exact historical version in `reference/local-gate4-integrated-docker-bun.mts` passed deterministic mode against production Docker/Bun. The portable version materialized by `configure.py` retains that flow but needs remote runtime validation. It:

- Reads the new quota Docker endpoint/container ID from `CTXPIPE_TEST_QUOTA_*` and the chat image from `CTXPIPE_CHAT_IMAGE`.
- Builds a per-test CA-derived image using `withNativeHttpsGitFixture`.
- Uses `withNativeChatFixture` with its optional third `{ listenHost }` argument.
- Requires an explicitly verified `CTXPIPE_CALLBACK_HOST` executor IPv4 address, binds the model/backend fixture to it, and uses it for `SANDBOX_CALLBACK_HOST` and `SANDBOX_MODEL_PROXY_HOST`.
- Fixes the fixture external model URL from loopback to that LAN address.
- Warms the actual production chat factory, checks helper/gh availability and absence of host keys, preserves an edited file, streams two stock turns, and checks transcript/terminal output.
- Captures only bounded live proxy output for diagnostics.

Portable live switch `CTXPIPE_LIVE_MODEL=1` captures the supplied `MODEL_PROVIDER_API_KEY`, `MODEL_PROVIDER`, `MODEL_PROVIDER_URL`, and `MODEL_FAST_NAME` from the remote environment before fixture initialization. It never reads the old checkout's `.env.local`. It has not yet passed the live journey. Do not print the captured settings/key object. Its current live prompt only reads local Git and asks for MCP; **that is insufficient to prove the authenticated Git helper/broker chain**. Extend it as below before claiming completion.

Private new helper:

`TASK/work/gate4-github-docker-route.mts`

This is **written but unexecuted/unvalidated**. `withGithubDockerRoute(gateway, fn)` forwards the real Docker HTTP/upgrade API to the configured loopback `CTXPIPE_TEST_QUOTA_DOCKER_HOST` / `CTXPIPE_TEST_QUOTA_DOCKER_PORT`. For **proxy-role container creation only**, it adds `github.com:<nested bridge gateway>` to `HostConfig.ExtraHosts`. It returns a temporary Docker API origin and a count of routed proxy creations. It does not log request bodies or credentials. Review it before running.

**This is an external test-network fixture only. Never ship its DNS override or API rewriting into production.** It allows the genuine native proxy to reach a controlled server at the exact GitHub authority while preserving real agent/proxy/credential behavior. All Docker operations still go to the real daemon.

### The sole WIP repository change

Read `TASK/work/private-gate4-evidence/handoff-github-fixture.md`.

`withNativeHttpsGitFixture` still takes `{ docker, baseImage }` and a callback. Its `git.serve(directory, callback, options)` now accepts:

```ts
{
  hostname: "github.com",
  repositoryPath: "/fixture/workspace.git",
  listenerPort: 443,
  basicAuth: {
    bootstrapToken: "fixture-bootstrap",
    readToken: "fixture-read-1",
  },
}
```

Defaults preserve the previous `host.docker.internal`, generated high port, unauthenticated `/repo.git` behavior. The returned `remote` has `url`, `sync()`, and `observedRequests()`; observations contain only method/path/auth category (`none`, `bootstrap`, `read`, `invalid`), not raw tokens. It maps the public path to real `/srv/repo.git`, performs an actual HTTPS Basic challenge, and uses a generated trusted CA with the GitHub SAN.

Port 443 runs the **trusted fixture Git server** as root to bind the port. This does **not** relax the production agent's UID 1000 requirement. Retain/check that distinction. The added generic validation/options are WIP; simplify unnecessary generality if doing so preserves this narrowly required proof. No runtime or full-project types have exercised this extension yet.

### Planned wiring — not implemented yet

1. Preserve the passing deterministic harness. Prefer a separate private authenticated/live script or a small explicit mode over repeatedly breaking the known-good file.
2. Construct the raw Docker client for the configured quota endpoint first; inspect its `bridge` gateway.
3. Use `withGithubDockerRoute` around the production native fixture lifetime. Set `DOCKER_HOST` to its returned temporary origin for production-created clients; retain the raw Docker client for the fixture server/image and inspections. Keep the API proxy alive until native sandbox cleanup completes, then restore the original env.
4. Use the new authenticated `git.serve` options above, yielding exactly `https://github.com/fixture/workspace.git`.
5. In the fixture org, insert a disposable GitHub `connections` record, e.g. installation 123456789/account `fixture`, update Workspace `workspaceRepositoryUrl` and `githubConnectionId`, and pass that same connection/revision/URL to preparation. Use a freshly generated RSA **fixture** App key in backend env, as in the existing native broker contract.
6. MSW should replace only the external installation-token endpoint (`https://api.github.com/app/installations/123456789/access_tokens`), returning `fixture-read-1` with future expiry and the exact read permissions. Record its requested repository scope. Other real HTTP/SDK operations must pass through. Follow `workspace-chat-git-credentials-native.contract.test.ts` for the correct shape. Do not mock the broker, lock, env injection, helper, native provider or Git.
7. Supply the separate `cloneToken: "fixture-bootstrap"` for initial native bootstrap. That should let preparation clone before the run capability exists. Inspect/assert that bootstrap does not persist this token in agent Git config.
8. Start the actual live Bun/TanStack/OpenCode turn with the authorized model key. Ask the agent to call `list_repositories` and run **`git ls-remote origin refs/heads/main`**, then read the local README. `ls-remote` is a read-only authenticated Git operation and avoids changing Git metadata solely for proof.
9. Assert model/tool success and one terminal, exact remote SHA/README result, at least one real Git-helper broker issuance for exactly `workspace`, and controlled Git observations with auth category `read`. The production model capability/env inheritance and both egress paths must execute. Verify the dirty file remains and native cleanup succeeds.
10. Assert no bootstrap/read credential is persisted in `.git/config`, `.git-credentials` or gh credential config. Do not put token text into model prompts/tool output merely to prove it exists. Git should consume it internally.
11. Clean the disposable connection/repository state and invalidate the fixture GitHub App cache as appropriate. Preserve original and cleanup failures. Do not delete unrelated DB rows or use broad Docker pruning.
12. Run targeted default-fixture regression and complete backend types for the WIP source before committing it. Record honest evidence and push the next coherent checkpoint.

### Historical topology lessons — adapt to the remote host

In the former Mac topology, the host reached the nested Docker **API** via a loopback published port, but dynamically published inner sandbox ports were on the **outer daemon container**, not automatically published on the host. The portable helper assumes the equivalent local outer-daemon topology; verify it on the remote executor. A readiness URL `0.0.0.0:4096` followed by `127.0.0.1:<dynamic>/session` connection refusal was a test topology problem, not production port allocation.

The configurable harness forwards each owned proxy's actual published port onto matching executor loopback through transparent `docker exec -i "$CTXPIPE_TEST_QUOTA_RUNNER_ID" nc -w 180 127.0.0.1 <port>`. Preserve native ingress authentication. It creates no alternate OpenCode owner. Do not change production advertised-host/port policy to accommodate this local setup; Compose clients live on the outer Docker network and reach `dind` normally.

Other resolved traps:

- Root fixture Docker client uses **120,000ms**, not 30,000ms, because CA/image commits can exceed 30s. Production runtime API also uses 120s; image discovery stays 30s.
- Both fixture model/backend listener and model provider URL must be reachable at the actual LAN address from Docker. A loopback model URL was wrong in this topology.
- Node 22 fetch does not automatically honor `HTTP_PROXY`; the installed Git helper uses explicit proxy transport. Don't replace it with bare fetch.
- Docker exec/attach requires HTTP upgrade/hijack forwarding. The native fault helper was fixed for that; transparent API fixtures must preserve it.
- `LogConfig: none` makes historical `docker.logs()` unsupported for native agent/proxy; use bounded live attach or native process diagnostics.
- Always remove the exact unique derived fixture tag even if its commit response was lost; otherwise `imageCreated`-flag cleanup leaks images. Default helper now does this.

### Do not add an unnecessary endurance requirement

A focused canonical-plan review confirmed that **one Docker OpenCode PID crossing a full installation-token expiry is not an explicit Gate 4 requirement**. Existing real helper tests invoke the helper twice across the issuer's **refresh window** under one native lease and prove renewal and post-lease rejection. Capability tests prove owner replacement/revocation.

Those compose with the live Docker journey **only once the actual agent-triggered helper → broker → proxy → controlled Git remote chain above passes**. Local `git rev-parse`, two plain model turns, or calling the helper directly from the host do not exercise that missing integration. Same-PID expiry endurance would be extra coverage; don't spend hours implementing it as an invented gate.

Likewise, uninterrupted active generation takeover across backend process death was previously rejected as an added requirement: ADR-030 uses native memory streaming and persisted-message reload. Do not build an application event journal/process takeover engine for it.

## 9. Railway: substantial implementation plus external prerequisites

Read `TASK/work/gate4-railway-feasibility-inventory.md`, prepared at handoff from source and the pinned `railway@3.11.0` SDK reference. The inventory is included; obtain published source remotely if needed.

**Do not report Railway as “implemented, only needs a token.”** Current code recognizes the selector but deliberately returns 503; there is no production Railway provider, SDK dependency, detached cleanup branch, or accepted live proof. Compose is locked to Docker.

SDK 3.11.0 provides durable create/connect/list/delete, filesystem, exec with kill/reattach, templates, checkpoints/restore and fork. These can support much of a native provider. However the inspected creation API does not expose required CPU/memory/PID/disk/user/capability/privileged/device controls, exact Git/model/MCP egress allowlisting, a native OpenCode ingress/`ports.connect` seam, or mutable handle env/host-bridge admission. `ISOLATED` means no environment-private access but still public NAT egress; it is not an exact egress policy.

Required work includes the accepted issue 08 custom TanStack `SandboxProvider`, supported enforcement strategy, native conformance, workspace checkpoint/fork lifecycle, resume/idle/GC cleanup, ingress and real Bun `chat + withSandbox + opencodeText` proof. Do not claim resource/network parity from VM isolation alone or weaken the product policy to make tests green. `sbx` currently also fails closed because the required disk/PID constraints are unavailable; unsandboxed is an explicit trusted mode, never an automatic fallback.

Missing live prerequisites: an entitled Railway Sandbox environment (Priority Boarding at the inspected version), `RAILWAY_ENVIRONMENT_ID`, and a scoped `RAILWAY_TOKEN` (preferred) or `RAILWAY_API_TOKEN`. No such usable access was found on the former host; inspect only the remote credentials actually provisioned. A prior user question about its location remained unanswered; don't repeatedly ask the same question. No callable Railway connector was available in this session. Tool availability can differ for the successor; inspect actual tools/local reference before assuming access.

Access is necessary but not sufficient. Determine supported capabilities accurately, identify any external product blocker, and present it honestly. You may do independent implementation/static work while access is unavailable, but cannot mark live conformance or Gate 4 accepted by assumption. Any proposed scope change must be explicit, not hidden in a new checklist.

## 10. Gate 4 closing protocol

Current three cumulative implementation defects were independently identified and then cleared:

1. Provider failures erased by Files/publish — fixed typed error/status propagation.
2. Agent-image ID compared with Node/proxy ref in base GC — fixed shared selector and immutable comparison.
3. Missing-agent detached deletion orphaned proxy/network — fixed durable native proxy locator/retry anchor.

Private artifacts:

- `work/private-gate4-evidence/gate4-spec-review-current.md` (original findings plus closure addendum)
- `work/private-gate4-evidence/gate4-entrypoint-audit-current.md`
- `work/gate4-railway-feasibility-inventory.md`

These clear **implementation findings**, not the complete gate. Fresh final cumulative spec and standards/adversarial reviews must assess the actual final pushed candidate and all required acceptance. An implementer must not be its own sole reviewer. The canonical plan requests a strong independent reviewer (`gpt-5.6-sol-high` in its original tool vocabulary); use an actually available equivalent and record what ran, rather than pretending an unavailable model slug worked. Cheaper agents are appropriate for tightly bounded implementation/read-only subtasks.

At gate close:

- Pin start and final SHAs; review full three-dot diff **and repository callers outside the changed paths**.
- Supply original 801-file scope manifest, requirements, evidence, migrations/builds, metrics/deletion data.
- Record requirement matrix, coverage map, blockers, obsolete owners/state, searches, owned later-gate follow-ups.
- Resolve blockers, push follow-ups, re-review final exact SHA to zero blockers.
- Use a `Gate 4:` completion commit subject per the canonical protocol (intermediate checkpoints used descriptive subjects).
- Record local/verified remote SHA, final CI, both review artifacts, proof/measurements and remaining owned follow-ups in the gate report.
- Only then advance the accepted gate number. Do not reinterpret a successful local test or an intermediate push as a closed gate.

Freshness caveat: `remaining.md` and older `status.md` retain historical pending wording. The newest pushed checkpoint, private passing run metadata and this handoff resolve the differences. Update the ledger as acceptance actually changes; do not rerun obsolete blockers merely because an old report still names them.

## 11. Gate 5 — frontend workflow simplification

This work has **not** been implemented yet. A preliminary map identified:

- `apps/ui/src/features/home/HomeComposer.tsx`: generates conversation/draft identity, module-global pending state, prepare and navigation choreography.
- `pending-workspace-compose.ts`: global pending compose ownership.
- `apps/ui/src/features/workspaces/WorkspaceChat.tsx`: reconciles route/compose/pending identities and uses render-time state repair.
- `WorkspaceChatSession.tsx`: native `useChat` plus autosend/sent-draft tracking/list insertion/route commit/title stages and duplicate prepare.
- `workspaceChatWebSocket.ts`: warmed socket without complete disposal ownership.
- `WorkspacePane.tsx`: separately derived identity, duplicate publication/status workflow, ~400ms polling.
- `WorkspaceSurface.tsx`: route/path identity separately owned from props.
- `conversationPublish.ts` and stories/tests contain related shared-state behavior.

Backend reusable seams include existing prepare/ensureConversation, `resolveWorkspaceChatSendRuntime`, native persistence/reconstruction/WS and immutable revision resolution. Inspect them; don't invent a parallel session manager.

Canonical steps:

1. One idempotent **server first-message command** replacing draft choreography.
2. Keep `useChat` as client session owner; only add missing disposal to the narrow WebSocket binding.
3. Canonical route/server identity; remove global pending reconciliation and render-time repair.
4. One owner for working-tree/publication state with versioned commands.
5. Explicit editor save/navigation semantics and ordered per-file writes.
6. Authoritative updates replace polling/blanket invalidation waterfalls.
7. Split `WorkspacePane` by responsibility **after** ownership moves, not as cosmetic file splitting first.

Suggested first vertical slice: server accepts first message idempotently and returns canonical conversation/run identity; Home sends one command, route attaches/hydrates native state without autosending a duplicate. The exact durable idempotency representation is **undecided**. One preliminary agent proposed a column/index; a scoped deterministic server ID derived from an opaque idempotency key might reuse existing uniqueness. Inspect authorization/replay/content-conflict semantics before choosing. Do not add a new table/registry by reflex. Generate any needed migration through Drizzle.

Required real Storybook/Playwright interactions:

- Strict Mode single acceptance/send.
- Late error ordering.
- Socket disposal on unmount/route changes.
- Reload/reconnect and rapid route changes.
- Edit then navigate; out-of-order saves.
- Shared publication pending state.
- Pierre keyboard/focus behavior.
- Stable-state request budget.

Audit all Home/compose/conversation/Files/Diff/Graph/Settings/push/PR routes and stories. Read UI AGENTS, React, Storybook, product-UI skills and DESIGN when applicable. MSW represents external HTTP/WS boundaries; real owned hooks/router/Query/components/Pierre execute. Do not add jsdom component tests, fake owned navigation or cosmetic decomposition that leaves duplicate owners alive.

## 12. Gate 6 — complete product acceptance and deletion

This is substantial remaining work, not a quick final lint pass.

- Mandatory deterministic Playwright golden journey using integrated UI/backend, migrated PG, controlled Git, local sandbox/OpenCode and scripted external model:
  1. Create/open Workspace.
  2. Home submits once.
  3. First text and exactly one terminal event.
  4. Reload persisted history.
  5. Second turn in same worktree.
  6. Edit a file and observe authoritative tree/diff.
  7. Commit/push session branch and create PR artifact.
  8. Restart backend and resume durable state.
  9. Delete/close and prove no orphan process/lease.
- Codesearch real toolchain, Storybook/accessibility, docs, migration upgrade, CDK and affected deployment/build gates based on the **full** PR scope.
- Eliminate the 124 backend and 223 UI diagnostic allowances; don't hide them under a passing allowlisted check.
- Delete characterization tests once stronger proof owns their invariant; remove redundant parallel fixtures/mocks.
- Remove temporary compatibility adapters/state columns/old ADR implementation paths **after migration proof**, including Gate 2 transitional revision/projection mappings where applicable. Preserve generic org-ingestion behavior until its retention/removal is explicitly decided.
- Retired immutable graph revision GC remains Gate 6 and must honor captured conversation lifetimes.
- Audit all runtime owners, callers, credential paths, schemas, workflows, UI, migrations and deployment surfaces. Nothing superseded should remain reachable accidentally.
- Compare final LOC, module count, owner count, requests and latency with the authoritative Gate 0 baseline; produce the positive deletion ledger.
- Measurements distinguish cold/warm (canonical plan asks at least 20 warm and 5 cold samples, p50/p95/max). Preserve the warm-turn budget: zero unnecessary GitHub calls, at most one lease attach, no new provider creation. Existing target is about five seconds for a useful first answer; measure honestly, not fixture startup/image-build time disguised as conversation latency.
- Final full CI and two cumulative zero-blocker reviews of the repository and pushed final SHA. Docs/ADRs must match shipped behavior.

Do not merge PR319 or release/deploy production just because gates pass unless that action is explicitly authorized separately. The approved goal here is completing the plan and durable branch checkpoints.

## 13. Handoff assets and evidence navigation

Transfer `ctxpipe-recovery-handoff-assets.tar.gz` manually to the remote task. It contains:

- This comprehensive document and `REMOTE-START-HERE.md` with full remote provisioning/restore commands.
- `repository-wip.patch` for the one uncommitted fixture extension, based on the pushed checkpoint.
- `configure.py`, `verify-manifest.py`, portable helper templates, test runner and CI partition utility.
- `reference/local-*`: original helper versions retained only to explain historical results. They contain old paths; never execute them unchanged remotely.
- Fixture handoff, Railway feasibility inventory, current implementation review/audit notes, and selected historical result JSON.
- `MANIFEST.json` listing hashes, base SHA, provenance and validation limits.

Git contains committed implementation, native patches, canonical plans, earlier gate evidence, CI/migrations and service/image recipes. No old source directory, live agent, Docker image, database or credential needs to be copied. Runtime/services must be recreated and secrets supplied through remote settings. No `.env`, production credential, database dump or dependency tree is bundled.

Use `REMOTE-START-HERE.md` for exact transfer, WIP detection/application and helper configuration. Both path configuration and network topology must be established on the new executor. Historical metadata can retain original paths without creating a remote dependency. Missing bulk raw logs must not be cited as if inspected.

Previous agent names (`gate0_spec_review`, `gate4_final_standards`, `gate4_native_ports`) refer to completed agents on the prior host. Their useful notes are bundled; do not try to resume those tool identities remotely. Delegate bounded new work where supported and useful.

## 14. Suggested first message for the successor

> Continue the ctxpipe recovery through Gate 6 on `codex/develop-plan-to-refocus-branch-direction`. Read `REMOTE-START-HERE.md`, this entire handoff and the canonical recovery plan before making changes. You have no access to the former computer: use the Git branch plus attached archive, configure the actual remote checkout paths, recreate infrastructure from tracked recipes, and use secrets supplied through the remote platform. Preserve pushed checkpoint `1c7b9657045ed56e62678c5a1d6a6e148925c04a` and the uncommitted HTTPS fixture extension. Gates 0–3 are complete; Gate 4 remains open. Check CI 34352646163 first, finish the actual Docker/OpenCode/helper/broker/authenticated-Git journey, resolve the Railway implementation/access constraints honestly, obtain final independent gate reviews, and proceed through Gates 5 and 6. All checkpoint pushes to this branch and existing model-key use are already authorized. Work economically without repeated permission questions, invented extra acceptance requirements, weakened security, or replacement lifecycle frameworks. Do not stop at a plan; carry the accepted plan to completion or report a precise unavoidable external blocker while completing all independent authorized work.
