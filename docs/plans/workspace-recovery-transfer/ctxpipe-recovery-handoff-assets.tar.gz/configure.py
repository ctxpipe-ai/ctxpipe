#!/usr/bin/env python3
"""Materialize private helper imports for this checkout; no install, network, or runtime work."""
from pathlib import Path
import argparse, json, subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);a=p.parse_args()
repo=Path(a.repo).resolve();bundle=Path(__file__).resolve().parent
if not (repo/'apps/backend/package.json').is_file(): p.error('Not a ctxpipe checkout')
# Single-quoted ESM import literals are generated; reject ambiguous path characters.
if any(c in str(repo) for c in "'\\\n\r"): p.error('Checkout path must not contain quotes, backslashes or line breaks')
base='1c7b9657045ed56e62678c5a1d6a6e148925c04a'
subprocess.run(['git','merge-base','--is-ancestor',base,'HEAD'],cwd=repo,check=True)
for name in ('gate4-integrated-docker-bun.mts','gate4-github-docker-route.mts'):
    target=bundle/'work'/name
    if target.exists(): p.error(str(target)+' already exists; preserve your edits before regenerating')
for name in ('gate4-integrated-docker-bun.mts','gate4-github-docker-route.mts'):
    text=(bundle/'templates'/name).read_text().replace('__CTXPIPE_REPO__',str(repo))
    (bundle/'work'/name).write_text(text)
print(json.dumps({'repo':str(repo),'helpers':str(bundle/'work'),'status':'Paths configured; runtime still unvalidated on this host'}))
